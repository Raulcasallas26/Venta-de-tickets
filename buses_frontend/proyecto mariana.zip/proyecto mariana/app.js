import Server from './models/server.js'
import 'dotenv/config.js'

const server =new Server

server.escuchar()

